package bpel.tp.residence;

import java.net.MalformedURLException;
import javax.servlet.ServletConfig;
import org.apache.cxf.jaxws.EndpointImpl;
import org.apache.cxf.transport.servlet.CXFNonSpringServlet;

public class ResidencePublisher extends CXFNonSpringServlet {

    @Override
    protected void loadBus(ServletConfig config) {
        super.loadBus(config);
        try {
            EndpointImpl endpoint = new EndpointImpl(getBus(), new ResidenceServiceImpl());
            endpoint.setWsdlLocation(config.getServletContext()
                .getResource("/WEB-INF/wsdl/residence.wsdl").toString());
            endpoint.publish("/ResidenceService");
        } catch (MalformedURLException e) {
            throw new IllegalStateException(e);
        }
    }
}
