package bpel.tp.residence;

import java.util.concurrent.atomic.AtomicInteger;
import javax.jws.WebService;

@WebService(
  serviceName       = "ResidenceService",
  portName          = "ResidencePort",
  endpointInterface = "bpel.tp.residence.ResidencePT",
  targetNamespace   = "http://tp.bpel/residence/",
  wsdlLocation      = "WEB-INF/wsdl/residence.wsdl"
)
public class ResidenceServiceImpl implements ResidencePT {

    private static final AtomicInteger NEXT_ROOM = new AtomicInteger(0);

    @Override public AssignResponse assignRoom(AssignRequest req) {
        int n = NEXT_ROOM.getAndIncrement();
        char block = (char) ('A' + (n / 20) % 4);
        return new AssignResponse(String.format("%c-%02d", block, n % 20 + 1));
    }
}
