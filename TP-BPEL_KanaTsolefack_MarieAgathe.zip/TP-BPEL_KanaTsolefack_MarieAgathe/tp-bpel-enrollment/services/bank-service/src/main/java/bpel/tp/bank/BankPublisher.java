package bpel.tp.bank;

import java.net.MalformedURLException;
import javax.servlet.ServletConfig;
import org.apache.cxf.jaxws.EndpointImpl;
import org.apache.cxf.transport.servlet.CXFNonSpringServlet;

public class BankPublisher extends CXFNonSpringServlet {

    @Override
    protected void loadBus(ServletConfig config) {
        super.loadBus(config);
        try {
            EndpointImpl endpoint = new EndpointImpl(getBus(), new BankServiceImpl());
            endpoint.setWsdlLocation(config.getServletContext()
                .getResource("/WEB-INF/wsdl/bank.wsdl").toString());
            endpoint.publish("/BankService");
        } catch (MalformedURLException e) {
            throw new IllegalStateException(e);
        }
    }
}
