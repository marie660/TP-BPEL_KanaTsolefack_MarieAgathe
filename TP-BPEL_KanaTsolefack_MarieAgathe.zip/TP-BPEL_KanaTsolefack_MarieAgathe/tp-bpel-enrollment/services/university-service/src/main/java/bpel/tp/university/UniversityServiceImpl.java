package bpel.tp.university;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import javax.jws.WebService;

@WebService(
  serviceName       = "UniversityService",
  portName          = "UniversityPort",
  endpointInterface = "bpel.tp.university.UniversityPT",
  targetNamespace   = "http://tp.bpel/university/",
  wsdlLocation      = "WEB-INF/wsdl/university.wsdl"
)
public class UniversityServiceImpl implements UniversityPT {

    private static final AtomicLong SEQUENCE = new AtomicLong(20260000);
    private static final Set<String> REGISTERED = ConcurrentHashMap.newKeySet();

    @Override public RegisterResponse register(RegisterRequest req) {
        String id = "STU-" + SEQUENCE.incrementAndGet();
        REGISTERED.add(id);
        System.out.println("[University] " + req.getStudent().getName()
            + " (" + req.getStudent().getProgram() + ") registered with ID " + id);
        return new RegisterResponse(id);
    }

    @Override public void cancel(CancelRequest req) {
        boolean removed = REGISTERED.remove(req.getStudentId());
        System.out.println("[University] registration " + req.getStudentId()
            + (removed ? " cancelled" : " not found"));
    }
}
