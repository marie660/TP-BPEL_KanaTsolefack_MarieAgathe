package bpel.tp.university;

import java.net.MalformedURLException;
import javax.servlet.ServletConfig;
import org.apache.cxf.jaxws.EndpointImpl;
import org.apache.cxf.transport.servlet.CXFNonSpringServlet;

public class UniversityPublisher extends CXFNonSpringServlet {

    @Override
    protected void loadBus(ServletConfig config) {
        super.loadBus(config);
        try {
            EndpointImpl endpoint = new EndpointImpl(getBus(), new UniversityServiceImpl());
            endpoint.setWsdlLocation(config.getServletContext()
                .getResource("/WEB-INF/wsdl/university.wsdl").toString());
            endpoint.publish("/UniversityService");
        } catch (MalformedURLException e) {
            throw new IllegalStateException(e);
        }
    }
}
