package bpel.tp.transport;

import java.util.concurrent.atomic.AtomicInteger;
import javax.jws.WebService;

@WebService(
  serviceName       = "TransportService",
  portName          = "TransportPort",
  endpointInterface = "bpel.tp.transport.TransportPT",
  targetNamespace   = "http://tp.bpel/transport/",
  wsdlLocation      = "WEB-INF/wsdl/transport.wsdl"
)
public class TransportServiceImpl implements TransportPT {

    private static final AtomicInteger NEXT_PASS = new AtomicInteger(700000);

    @Override public ActivateResponse activatePass(ActivateRequest req) {
        return new ActivateResponse("BUS-" + NEXT_PASS.incrementAndGet());
    }
}
