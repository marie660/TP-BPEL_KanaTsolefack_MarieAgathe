package bpel.tp.transport;

import java.net.MalformedURLException;
import javax.servlet.ServletConfig;
import org.apache.cxf.jaxws.EndpointImpl;
import org.apache.cxf.transport.servlet.CXFNonSpringServlet;

public class TransportPublisher extends CXFNonSpringServlet {

    @Override
    protected void loadBus(ServletConfig config) {
        super.loadBus(config);
        try {
            EndpointImpl endpoint = new EndpointImpl(getBus(), new TransportServiceImpl());
            endpoint.setWsdlLocation(config.getServletContext()
                .getResource("/WEB-INF/wsdl/transport.wsdl").toString());
            endpoint.publish("/TransportService");
        } catch (MalformedURLException e) {
            throw new IllegalStateException(e);
        }
    }
}
