package bpel.tp.transport.events;

import bpel.tp.transport.ActivateRequest;
import bpel.tp.transport.ActivateResponse;
import bpel.tp.transport.TransportServiceImpl;
import java.time.OffsetDateTime;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

@Component
class TransportListener {
  @Autowired private JmsTemplate jms;
  @Autowired private TransportServiceImpl transport;

  private final Map<String, Event> payments = new HashMap<>();
  private final Map<String, Event> myEvents = new HashMap<>();
  private final Map<String, Event> rooms    = new HashMap<>();

  @JmsListener(destination = "PaymentDecided")
  public void onPaymentDecided(String json) throws Exception {
    Event e = Event.parse(json);
    if (!e.data.get("approved").asBoolean()) {
      return;
    }
    ActivateResponse r = transport.activatePass(new ActivateRequest(
        e.data.get("studentId").asText()));

    Event out = Event.of("PassActivated", e.correlationId,
        Map.of("studentId", e.data.get("studentId").asText(),
               "passId",    r.getPassId()));
    synchronized (this) {
      payments.put(e.correlationId, e);
      myEvents.put(e.correlationId, out);
    }
    jms.convertAndSend("PassActivated", out.toJson());
    completeIfLast(e.correlationId);
  }

  @JmsListener(destination = "RoomAssigned")
  public void onRoomAssigned(String json) throws Exception {
    Event e = Event.parse(json);
    synchronized (this) {
      rooms.put(e.correlationId, e);
    }
    completeIfLast(e.correlationId);
  }

  private void completeIfLast(String correlationId) throws Exception {
    Event payment, pass, room;
    synchronized (this) {
      pass = myEvents.get(correlationId);
      room = rooms.get(correlationId);
      if (pass == null || room == null) {
        return;
      }
      payment = payments.remove(correlationId);
      myEvents.remove(correlationId);
      rooms.remove(correlationId);
    }
    boolean iAmLast = !OffsetDateTime.parse(room.timestamp)
        .isAfter(OffsetDateTime.parse(pass.timestamp));
    if (!iAmLast) {
      return;
    }
    Event out = Event.of("EnrollmentCompleted", correlationId,
        Map.of("status",     "ENROLLED",
               "studentId",  pass.data.get("studentId").asText(),
               "roomNumber", room.data.get("roomNumber").asText(),
               "passId",     pass.data.get("passId").asText(),
               "receipt",    payment.data.get("receipt").asText()));
    jms.convertAndSend("EnrollmentCompleted", out.toJson());
  }
}
