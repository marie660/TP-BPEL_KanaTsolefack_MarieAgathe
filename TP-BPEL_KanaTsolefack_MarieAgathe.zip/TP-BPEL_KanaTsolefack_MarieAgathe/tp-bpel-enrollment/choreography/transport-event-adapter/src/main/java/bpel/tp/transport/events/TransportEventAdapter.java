package bpel.tp.transport.events;

import bpel.tp.transport.TransportServiceImpl;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;
import org.springframework.jms.annotation.EnableJms;

@SpringBootApplication
@EnableJms
@Import(TransportServiceImpl.class)
public class TransportEventAdapter {
  public static void main(String[] a) { SpringApplication.run(TransportEventAdapter.class, a); }
}
