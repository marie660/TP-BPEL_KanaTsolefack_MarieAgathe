package bpel.tp.university.events;

import bpel.tp.university.CancelRequest;
import bpel.tp.university.RegisterRequest;
import bpel.tp.university.RegisterResponse;
import bpel.tp.university.UniversityServiceImpl;
import com.fasterxml.jackson.databind.JsonNode;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

@Component
class UniversityListener {
  @Autowired private JmsTemplate jms;
  @Autowired private UniversityServiceImpl university;

  @JmsListener(destination = "EnrollmentRequested")
  public void onEnrollmentRequested(String json) throws Exception {
    Event e = Event.parse(json);
    JsonNode student = e.data.get("student");
    RegisterResponse r = university.register(new RegisterRequest(
        new RegisterRequest.Student(
            student.get("name").asText(),
            student.get("program").asText())));

    Event out = Event.of("StudentRegistered", e.correlationId,
        Map.of("studentId", r.getStudentId(),
               "amount",    e.data.get("amount").asText()));
    jms.convertAndSend("StudentRegistered", out.toJson());
  }

  @JmsListener(destination = "PaymentDecided")
  public void onPaymentDecided(String json) throws Exception {
    Event e = Event.parse(json);
    if (e.data.get("approved").asBoolean()) {
      return;
    }
    String studentId = e.data.get("studentId").asText();
    university.cancel(new CancelRequest(studentId));

    Event out = Event.of("EnrollmentCompleted", e.correlationId,
        Map.of("status",    "REFUSED",
               "studentId", studentId));
    jms.convertAndSend("EnrollmentCompleted", out.toJson());
  }
}
