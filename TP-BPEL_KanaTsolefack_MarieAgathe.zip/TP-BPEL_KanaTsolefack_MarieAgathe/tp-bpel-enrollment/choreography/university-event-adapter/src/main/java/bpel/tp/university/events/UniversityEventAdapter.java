package bpel.tp.university.events;

import bpel.tp.university.UniversityServiceImpl;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;
import org.springframework.jms.annotation.EnableJms;

@SpringBootApplication
@EnableJms
@Import(UniversityServiceImpl.class)
public class UniversityEventAdapter {
  public static void main(String[] a) { SpringApplication.run(UniversityEventAdapter.class, a); }
}
