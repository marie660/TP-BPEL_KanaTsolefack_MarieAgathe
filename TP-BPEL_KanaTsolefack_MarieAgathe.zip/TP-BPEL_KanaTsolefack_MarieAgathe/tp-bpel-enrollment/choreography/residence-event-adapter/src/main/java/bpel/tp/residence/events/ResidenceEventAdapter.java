package bpel.tp.residence.events;

import bpel.tp.residence.ResidenceServiceImpl;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;
import org.springframework.jms.annotation.EnableJms;

@SpringBootApplication
@EnableJms
@Import(ResidenceServiceImpl.class)
public class ResidenceEventAdapter {
  public static void main(String[] a) { SpringApplication.run(ResidenceEventAdapter.class, a); }
}
