package bpel.tp.residence.events;

import bpel.tp.residence.AssignRequest;
import bpel.tp.residence.AssignResponse;
import bpel.tp.residence.ResidenceServiceImpl;
import java.time.OffsetDateTime;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

@Component
class ResidenceListener {
  @Autowired private JmsTemplate jms;
  @Autowired private ResidenceServiceImpl residence;

  private final Map<String, Event> payments = new HashMap<>();
  private final Map<String, Event> myEvents = new HashMap<>();
  private final Map<String, Event> passes   = new HashMap<>();

  @JmsListener(destination = "PaymentDecided")
  public void onPaymentDecided(String json) throws Exception {
    Event e = Event.parse(json);
    if (!e.data.get("approved").asBoolean()) {
      return;
    }
    AssignResponse r = residence.assignRoom(new AssignRequest(
        e.data.get("studentId").asText()));

    Event out = Event.of("RoomAssigned", e.correlationId,
        Map.of("studentId",  e.data.get("studentId").asText(),
               "roomNumber", r.getRoomNumber()));
    synchronized (this) {
      payments.put(e.correlationId, e);
      myEvents.put(e.correlationId, out);
    }
    jms.convertAndSend("RoomAssigned", out.toJson());
    completeIfLast(e.correlationId);
  }

  @JmsListener(destination = "PassActivated")
  public void onPassActivated(String json) throws Exception {
    Event e = Event.parse(json);
    synchronized (this) {
      passes.put(e.correlationId, e);
    }
    completeIfLast(e.correlationId);
  }

  private void completeIfLast(String correlationId) throws Exception {
    Event payment, room, pass;
    synchronized (this) {
      room = myEvents.get(correlationId);
      pass = passes.get(correlationId);
      if (room == null || pass == null) {
        return;
      }
      payment = payments.remove(correlationId);
      myEvents.remove(correlationId);
      passes.remove(correlationId);
    }
    boolean iAmLast = OffsetDateTime.parse(room.timestamp)
        .isAfter(OffsetDateTime.parse(pass.timestamp));
    if (!iAmLast) {
      return;
    }
    Event out = Event.of("EnrollmentCompleted", correlationId,
        Map.of("status",     "ENROLLED",
               "studentId",  room.data.get("studentId").asText(),
               "roomNumber", room.data.get("roomNumber").asText(),
               "passId",     pass.data.get("passId").asText(),
               "receipt",    payment.data.get("receipt").asText()));
    jms.convertAndSend("EnrollmentCompleted", out.toJson());
  }
}
