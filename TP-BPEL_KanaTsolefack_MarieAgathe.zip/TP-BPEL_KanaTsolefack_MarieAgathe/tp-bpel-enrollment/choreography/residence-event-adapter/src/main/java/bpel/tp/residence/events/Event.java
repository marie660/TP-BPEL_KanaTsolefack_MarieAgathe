package bpel.tp.residence.events;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Map;
import java.util.UUID;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Event {
  static final String SOURCE = "residence-service";
  private static final ObjectMapper JSON = new ObjectMapper();

  public String eventId;
  public String correlationId;
  public String timestamp;
  public String source;
  public String type;
  public JsonNode data;

  public static Event of(String type, String correlationId, Map<String, Object> data) {
    Event event = new Event();
    event.eventId       = UUID.randomUUID().toString();
    event.correlationId = correlationId;
    event.timestamp     = OffsetDateTime.now(ZoneOffset.UTC).toString();
    event.source        = SOURCE;
    event.type          = type;
    event.data          = JSON.valueToTree(data);
    return event;
  }

  public static Event parse(String json) throws Exception {
    return JSON.readValue(json, Event.class);
  }

  public String toJson() throws Exception {
    return JSON.writeValueAsString(this);
  }
}
