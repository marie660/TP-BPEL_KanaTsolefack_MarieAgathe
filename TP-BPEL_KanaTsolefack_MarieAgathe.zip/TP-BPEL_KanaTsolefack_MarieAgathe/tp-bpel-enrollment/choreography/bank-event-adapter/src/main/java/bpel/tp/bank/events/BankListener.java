package bpel.tp.bank.events;

import bpel.tp.bank.BankServiceImpl;
import bpel.tp.bank.PayRequest;
import bpel.tp.bank.PayResponse;
import java.math.BigDecimal;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

@Component
class BankListener {
  @Autowired private JmsTemplate jms;
  @Autowired private BankServiceImpl bank;

  @JmsListener(destination = "StudentRegistered")
  public void onStudentRegistered(String json) throws Exception {
    Event e = Event.parse(json);
    PayResponse r = bank.pay(new PayRequest(
        e.data.get("studentId").asText(),
        new BigDecimal(e.data.get("amount").asText())));

    Event out = Event.of("PaymentDecided", e.correlationId,
        Map.of("studentId", e.data.get("studentId").asText(),
               "approved",  r.isApproved(),
               "receipt",   r.getReceipt()));
    jms.convertAndSend("PaymentDecided", out.toJson());
  }
}
