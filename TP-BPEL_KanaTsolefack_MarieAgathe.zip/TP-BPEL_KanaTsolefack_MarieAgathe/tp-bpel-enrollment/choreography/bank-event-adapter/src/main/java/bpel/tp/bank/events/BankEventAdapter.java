package bpel.tp.bank.events;

import bpel.tp.bank.BankServiceImpl;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;
import org.springframework.jms.annotation.EnableJms;

@SpringBootApplication
@EnableJms
@Import(BankServiceImpl.class)
public class BankEventAdapter {
  public static void main(String[] a) { SpringApplication.run(BankEventAdapter.class, a); }
}
